package com.example.myfragment;

import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;

import com.example.myfragment.Fragment.FavoriteFragment;
import com.example.myfragment.Fragment.HomeFragment;
import com.example.myfragment.Fragment.ProfileFragment;

public class MainActivity extends AppCompatActivity {
    BottomNavigationView bnvNav;
    HomeFragment homeFragment;
    ProfileFragment profileFragment;
    FavoriteFragment favoriteFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        homeFragment = new HomeFragment();
        profileFragment = new ProfileFragment();
        favoriteFragment = new FavoriteFragment();

        changeFragment(homeFragment);

        bnvNav = findViewById(R.id.bnvMain);

        bnvNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.menu_home:
                        changeFragment(homeFragment);
                        break;
                    case R.id.menu_favorite:
                        changeFragment(favoriteFragment);
                        break;
                    case R.id.menu_profile:
                        changeFragment(favoriteFragment);
                        break;
                }

                return true;
            }
        });
    }

    private void changeFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.frame_main, fragment)
                .commit();
    }
}
